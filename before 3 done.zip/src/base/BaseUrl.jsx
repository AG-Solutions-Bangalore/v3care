const BASE_URL = "https://agsdraft.online/app/public";

export default BASE_URL;
